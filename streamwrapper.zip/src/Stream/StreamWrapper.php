<?php

namespace Simp\StreamWrapper\Stream;

abstract class StreamWrapper extends GlobalStreamWrapper {}